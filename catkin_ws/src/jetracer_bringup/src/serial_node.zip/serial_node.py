#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist
#from racecar import NvidiaRacecar

class SerialNode:
    def __init__(self):
        rospy.init_node('serial_node')
        rospy.Subscriber('/cmd_vel', Twist, self.cmd_vel_callback)
        self.car = NvidiaRacecar()

    def cmd_vel_callback(self, msg):
        self.car.steering = msg.angular.z
        self.car.throttle = msg.linear.x

if __name__ == '__main__':
    node = SerialNode()
    rospy.spin()

